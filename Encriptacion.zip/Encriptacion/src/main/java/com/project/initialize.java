package com.project;

public interface initialize {

}
