# Exemple de Threads a JavaFX #

En aquest projecte es pot veure dos exemples de com fer tasques en fils paral·lels fent servir FixedThreadPool i CompletableFuture a JavaFX

### Compilació i funcionament ###

Cal el 'Maven' per compilar el projecte
```bash
mvn clean
mvn compile
```

Per executar el projecte a Windows cal
```bash
.\run.ps1 com.project.Main
```

Per executar el projecte a Linux/macOS cal
```bash
./run.sh com.project.Main
```

